# AMBER was run with the following command:
/home/finlayclark/software/amber20/bin/pmemd -O -i amber.cfg -p amber.prm7 -c amber.rst7 -o stdout -r amber.crd -inf amber.nrg
